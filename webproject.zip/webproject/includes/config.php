<?php
	define('DB_HOST', 'localhost');
	define('DB_NAME', 'project');
	define('DB_USER', 'root');
	define('DB_PASSWORD', '');
?>